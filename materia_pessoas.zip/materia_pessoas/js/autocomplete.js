$(document).ready(function() {
    // Configuração do autocomplete para buscar policiais
    $('#buscaPolicial').autocomplete({
        source: function(request, response) {
            $.ajax({
                url: window.location.href,
                type: 'POST',
                data: {
                    action: 'buscar_policiais_autocomplete',
                    term: request.term
                },
                success: function(data) {
                    response(JSON.parse(data));
                },
                error: function() {
                    alert('Erro na busca de policiais.');
                }
            });
        },
        minLength: 2,
        select: function(event, ui) {
            if (ui.item) {
                // Preenche os campos com os dados retornados
                $('#buscaPolicial').data('selected-policial', ui.item);
                $('#buscaPolicial').val(ui.item.label); // Exibe o nome completo no campo

                // Preenche o campo Posto/Graduação
                $('#postoGraduacao').html('<option value="' + ui.item.pg_descricao + '">' + ui.item.pg_descricao + '</option>');

                // Preenche o campo Unidade
                $('#unidade').html('<option value="' + ui.item.unidade + '">' + ui.item.unidade + '</option>');

                // Habilita os campos (caso estejam desabilitados)
                $('#postoGraduacao').prop('disabled', false);
                $('#unidade').prop('disabled', false);
            } else {
                alert("Erro ao carregar os dados do policial. Verifique as informações na base de dados.");
            }
            return false; // Impede o autocomplete de substituir o campo com apenas o valor do 'label'
        }
    });

    // Adicionar pessoa à tabela de pessoas associadas
    $('#btnAdicionarPM').click(function() {
        var policial = $('#buscaPolicial').data('selected-policial');
        var unidade = $('#unidade').val();
        var postoGraduacao = $('#postoGraduacao').val();

        if (!policial || !unidade || !postoGraduacao) {
            alert('Preencha todos os campos antes de adicionar.');
            return;
        }

        // Verifica se a tabela está vazia
        var tabela = $('#tabelaPessoas tbody');
        var linhas = tabela.find('tr');
        if (linhas.length === 1 && linhas.find('td').length === 1) {
            linhas.remove(); // Remove a linha "Nenhum registro encontrado."
        }

        // Verifica se o policial já foi adicionado
        if ($('tr[data-matricula="' + policial.matricula + '"]').length > 0) {
            alert('Este policial já foi adicionado.');
            return;
        }

        // Adiciona a nova linha na tabela
        var novaLinha = `
            <tr data-matricula="${policial.matricula}">
                <td>
                    <button class="btn btn-danger btn-sm" onclick="excluirRegistro('${policial.matricula}')">Excluir</button>
                    <button class="btn btn-warning btn-sm btnEditar" style="margin-left: 5px;">Editar</button>
                </td>
                <td>${policial.nome}</td>
                <td>${postoGraduacao}</td>
                <td>${unidade}</td>
            </tr>
        `;
        tabela.append(novaLinha);

        // Limpa os campos de entrada
        $('#buscaPolicial').val('');
        $('#buscaPolicial').removeData('selected-policial');
        $('#unidade').html('<option value="">Selecione a Unidade</option>');
        $('#postoGraduacao').html('<option value="">Selecione o Posto/Graduação</option>');
    });

    // Listener para os botões de edição
    $('#tabelaPessoas').on('click', '.btnEditar', function() {
        var linha = $(this).closest('tr');
        var matricula = linha.data('matricula');

        // Evita múltiplas edições simultâneas
        if (linha.hasClass('editando')) {
            return;
        }
        linha.addClass('editando');

        // Obter os valores atuais
        var postoAtual = linha.find('td:nth-child(3)').text();
        var unidadeAtual = linha.find('td:nth-child(4)').text();

        // Criar os elementos de seleção para Posto/Graduação
        var selectPosto = $('<select class="form-select form-select-sm posto-select"></select>');
        postosGraduacoes.forEach(function(posto) {
            var option = $('<option></option>')
                .attr('value', posto.pg_descricao)
                .text(posto.pg_descricao);
            if (posto.pg_descricao === postoAtual) {
                option.attr('selected', 'selected');
            }
            selectPosto.append(option);
        });

        // Criar os elementos de seleção para Unidade
        var selectUnidade = $('<select class="form-select form-select-sm unidade-select"></select>');
        subunidades.forEach(function(subunidade) {
            var option = $('<option></option>')
                .attr('value', subunidade.descricao)
                .text(subunidade.descricao);
            if (subunidade.descricao === unidadeAtual) {
                option.attr('selected', 'selected');
            }
            selectUnidade.append(option);
        });

        // Substituir os textos por selects
        linha.find('td:nth-child(3)').html(selectPosto);
        linha.find('td:nth-child(4)').html(selectUnidade);

        // Alterar os botões de ação
        var btnSalvar = $('<button class="btn btn-success btn-sm btnSalvar" style="margin-left: 5px;">Salvar</button>');
        var btnCancelar = $('<button class="btn btn-secondary btn-sm btnCancelar" style="margin-left: 5px;">Cancelar</button>');
        $(this).replaceWith(btnSalvar);
        $(this).siblings('.btnExcluir').replaceWith(btnCancelar);
    });

    // Listener para os botões de salvar
    $('#tabelaPessoas').on('click', '.btnSalvar', function() {
        var linha = $(this).closest('tr');
        var matricula = linha.data('matricula');

        // Obter os valores selecionados
        var novoPosto = linha.find('.posto-select').val();
        var novaUnidade = linha.find('.unidade-select').val();

        // Atualizar os campos com os novos valores
        linha.find('td:nth-child(3)').text(novoPosto);
        linha.find('td:nth-child(4)').text(novaUnidade);

        // Restaurar os botões de ação
        var btnEditar = $('<button class="btn btn-warning btn-sm btnEditar" style="margin-left: 5px;">Editar</button>');
        var btnExcluir = $('<button class="btn btn-danger btn-sm btnExcluir" onclick="excluirRegistro(\'' + matricula + '\')">Excluir</button>');
        $(this).replaceWith(btnEditar);
        $(this).siblings('.btnCancelar').replaceWith(btnExcluir);

        // Remover a classe 'editando'
        linha.removeClass('editando');
    });

    // Listener para os botões de cancelar
    $('#tabelaPessoas').on('click', '.btnCancelar', function() {
        var linha = $(this).closest('tr');
        var matricula = linha.data('matricula');

        // Obter os valores atuais do select para restaurar
        var selectPosto = linha.find('.posto-select');
        var selectUnidade = linha.find('.unidade-select');
        var postoOriginal = selectPosto.find('option:selected').text();
        var unidadeOriginal = selectUnidade.find('option:selected').text();

        // Restaurar os textos originais
        linha.find('td:nth-child(3)').text(postoOriginal);
        linha.find('td:nth-child(4)').text(unidadeOriginal);

        // Restaurar os botões de ação
        var btnEditar = $('<button class="btn btn-warning btn-sm btnEditar" style="margin-left: 5px;">Editar</button>');
        var btnExcluir = $('<button class="btn btn-danger btn-sm btnExcluir" onclick="excluirRegistro(\'' + matricula + '\')">Excluir</button>');
        $(this).replaceWith(btnEditar);
        $(this).siblings('.btnSalvar').replaceWith(btnExcluir);

        // Remover a classe 'editando'
        linha.removeClass('editando');
    });
});

// Função para excluir o registro
function excluirRegistro(matricula) {
    $('tr[data-matricula="' + matricula + '"]').remove();

    // Se a tabela estiver vazia, adiciona a linha "Nenhum registro encontrado."
    var tabela = $('#tabelaPessoas tbody');
    if (tabela.find('tr').length === 0) {
        tabela.append('<tr><td colspan="4" class="text-center">Nenhum registro encontrado.</td></tr>');
    }
}
