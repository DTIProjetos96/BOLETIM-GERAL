<?php
// Função para buscar os dados do policial com base na matrícula
function buscarDadosPolicial($pdo, $matricula) {
    if ($matricula) {
        try {
            // Consulta para buscar os dados do policial, incluindo a unidade
            $stmt = $pdo->prepare("
                SELECT matricula, nome, pg_descricao, unidade
                FROM vw_policiais_militares
                WHERE matricula = :matricula
                LIMIT 1
            ");
            $stmt->execute(['matricula' => $matricula]);
            $dados = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($dados) {
                return ['success' => true, 'dados' => $dados];
            } else {
                return ['success' => false, 'message' => 'Policial não encontrado.'];
            }
        } catch (PDOException $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    } else {
        return ['success' => false, 'message' => 'Matrícula não informada.'];
    }
}

// Ação para buscar policiais para o autocomplete com base no CPF, nome ou matrícula
function buscarPoliciaisAutocomplete($pdo, $term) {
    $stmt = $pdo->prepare("SELECT matricula, nome, cpf, unidade, pg_descricao 
                           FROM bg.vw_policiais_militares 
                           WHERE nome ILIKE :term OR cpf ILIKE :term OR matricula::TEXT ILIKE :term 
                           LIMIT 10");
    $stmt->execute(['term' => '%' . $term . '%']);
    $policiais = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $results = [];
    foreach ($policiais as $policial) {
        $results[] = [
            'label' => "{$policial['nome']} - {$policial['cpf']} - {$policial['matricula']}",
            'matricula' => $policial['matricula'],
            'nome' => $policial['nome'],
            'cpf' => $policial['cpf'],
            'unidade' => $policial['unidade'], // Garante que unidade está presente
            'pg_descricao' => $policial['pg_descricao'] // Garante que posto/graduação está presente
        ];
    }

    return $results;
}

// Recupera as opções para o campo Subunidade
$stmt_subunidade = $pdo->prepare("
    SELECT subu_cod, concat(subu_descricao, ' - ', unid_descricao, ' - ', coma_descricao) as descricao
    FROM public.vw_comando_unidade_subunidade 
    WHERE subu_cod IN (
        SELECT fk_subunidade
        FROM bg.vw_permissao 
        WHERE fk_login = :login AND perm_ativo = 1
    )
    ORDER BY subu_descricao, unid_descricao, coma_descricao
");
$stmt_subunidade->execute(['login' => $user_login]);
$subunidades = $stmt_subunidade->fetchAll(PDO::FETCH_ASSOC); 


// Recupera as opções para o campo Posto/Graduação
function buscarPostosGraduacoes($pdo) {
    try {
        $stmt_pg = $pdo->query("SELECT DISTINCT pg_descricao FROM bg.vw_policiais_militares ORDER BY pg_descricao");
        return $stmt_pg->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Erro ao buscar postos/graduações: " . $e->getMessage());
        return [];
    }
}

// Busca as unidades para o datalist
function buscarUnidades($pdo) {
    try {
        $stmt_unidades = $pdo->query("SELECT DISTINCT unidade FROM bg.vw_policiais_militares ORDER BY unidade");
        return $stmt_unidades->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Erro ao buscar unidades: " . $e->getMessage());
        return [];
    }
}

?>
